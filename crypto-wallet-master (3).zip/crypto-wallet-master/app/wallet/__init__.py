from flask import Blueprint

wallet_bp = Blueprint('wallet', __name__, template_folder='templates')

from . import routes